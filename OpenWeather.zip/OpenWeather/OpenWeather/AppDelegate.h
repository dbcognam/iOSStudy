//
//  AppDelegate.h
//  OpenWeather
//
//  Created by JeonYongNam on 2014. 2. 4..
//  Copyright (c) 2014년 JeonYongNam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UINavigationController *navigationController1;
@property (strong, nonatomic) UINavigationController *navigationController2;
@property (strong, nonatomic) UINavigationController *navigationController3;
@property (strong, nonatomic) UINavigationController *navigationController4;

@property (strong, nonatomic) UIWindow *window;

@end
