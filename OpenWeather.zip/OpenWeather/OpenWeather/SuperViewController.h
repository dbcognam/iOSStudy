//
//  SuperViewController.h
//  OpenWeather
//
//  Created by JeonYongNam on 2014. 2. 5..
//  Copyright (c) 2014년 JeonYongNam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuperViewController : UIViewController

@end
